# DataSense-Analyzer: Personal Project 🧑‍💻

Hello! This project, **DataSense-Analyzer**, is a personal initiative driven by my learning goals to develop my skills in Python, data analysis, and Machine Learning. The main objective is to build a simple yet robust tool for quickly understanding the content of any given dataset.

## 💡 The Concept

DataSense-Analyzer scans a folder containing various file types (CSV, Images, Audio, Text) to provide a **quick diagnostic** of the dataset's content and what type of Machine Learning problem it could address (Supervised, Unsupervised, etc.).

## ✨ What the Code Does

* **Multimodal Analysis:** It doesn't just look at tables (CSV); it attempts to analyze the content of **images** (using a simple model) and **audio** (using basic statistics).
* **Fast Startup:** I implemented a **Lazy Loading** system for heavy dependencies (PyTorch, Spark). If your dataset has no images, these heavy tools are not loaded, making the script lighter and faster to start.
* **Big File Handling (Optional):** It can use **PySpark** to manage very large CSV or JSON files efficiently (if the library is installed).

## 🚀 Installation (Simple)

If you want to test the tool, here is how to install it.

### 1. Basic Installation

This installs the necessary libraries for table analysis (Pandas, etc.):

```bash
pip install datasense-analyzer
```

### 2. Complete Installation (for Image and Audio Analysis)

If you want to include image and audio file analysis, you need to install extra dependencies:

```bash
pip install datasense-analyzer[all]
```

## Usage

Once installed, launch the analysis from your terminal using the datasense command:

```bash
datasense path/vers/mon_dossier --output-json rapport.json --verbose
```

| Argument           | Rôle                                                        |
|-------------------|-------------------------------------------------------------|
| path              | Required. Path to the folder or file.         |
| -o, --output-json | Saves the analysis summary to a JSON file.    |
| -v, --verbose     | Displays more details directly in the console.  

