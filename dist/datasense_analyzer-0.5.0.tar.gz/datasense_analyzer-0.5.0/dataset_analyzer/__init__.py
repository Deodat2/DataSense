# dataset_analyzer/__init__.py
from .core import dataset_identity
